from django.contrib.auth import views as auth_views
from django.urls import path

from . import views



urlpatterns = [
    # Normal

    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('map/', views.current_location, name='map'),
    path('user/profile', views.user_profile, name='profile'),

    # Signup
    path('register/', views.register, name='register'),

    # Authentication
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name="logout"),
]
