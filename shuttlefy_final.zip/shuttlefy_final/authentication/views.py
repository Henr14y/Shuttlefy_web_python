from django.contrib import messages
from django.contrib.auth import login, authenticate, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import EmailMessage
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

from .forms import CustomUserCreationForm
from .tokens import token_generator


# Create your views here.

def token_email(user, current_site, path, email_subject, template_name, to_email, from_email):
    message = render_to_string(template_name=template_name, context={
        'user': user,
        'domain': current_site.domain,
        'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(),
        'token': token_generator.make_token(user),
        'path': path
    }).strip()
    email = EmailMessage(subject=email_subject, body=message, to=[to_email], from_email=from_email, )
    email.send()


def index(request):
    return render(request=request, template_name="authentication/index.html", )


def about(request):
    return render(request=request, template_name="authentication/about.html", )


# @login_required
def current_location(request):
    return render(request=request, template_name="authentication/map.html", )


@login_required
def user_profile(request):
    User = get_user_model()
    user = get_object_or_404(User, pk=request.user.id)
    patients = user.patients.all()
    return render(request, 'authentication/dashboard.html', {'user': user, 'patients': patients})


def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(data=request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            messages.success(request, "Registration successful!")
            return redirect('index')
        else:
            messages.error(request, "Registration failed!")
            args = {'form': form}
            return render(request, 'authentication/register.html', args)
    else:
        form = CustomUserCreationForm()

    args = {'form': form}
    return render(request, 'authentication/register.html', args)


def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, "Logged in successful!")
                return redirect('index')
            else:
                print("Error\n\n\n\n")
                messages.error(request, "Invalid username or password.")
        else:
            print("Error 2\n\n\n\n")
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()

    return render(request=request,
                  template_name="authentication/login.html",
                  context={"form": form})


@login_required
def user_logout(request):
    logout(request)
    messages.success(request, "Logged out successful!")
    return redirect("index")
